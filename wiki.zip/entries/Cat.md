#Cat
Cats are wonderful creatures that are largely indifferent to humans except when serving their own interests, like obtaining shelter and food. Still, they are fun to have around. 

##Cat Fact
Cats enjoy Friskies. 